<?php
// Inclure le fichier de connexion à la base de données
require_once 'db.php';
// Vérifier que les données POST sont reçues
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupérer les données soumises via POST
    $email = trim($_POST['email']); // Supprimer les espaces inutiles
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Vérifier que l'e-mail est valide
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("Adresse e-mail invalide.");
    }

    // Vérifier que les mots de passe correspondent
    if ($password !== $confirm_password) {
        die("Les mots de passe ne correspondent pas.");
    }

    // Vérifier que le mot de passe respecte les règles de sécurité
    if (strlen($password) < 12) {
        die("Le mot de passe doit contenir au moins 12 caractères.");
    }

    // Vérifier si l'e-mail existe déjà dans la base de données
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $count = $stmt->fetchColumn();

    if ($count > 0) {
        die("Cet e-mail est déjà enregistré. Veuillez utiliser un autre e-mail.");
    }

    // Hachage du mot de passe
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    // Insérer l'utilisateur dans la base de données
    try {
        $stmt = $pdo->prepare("INSERT INTO users (email, password) VALUES (:email, :password)");
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':password', $hashed_password);

        if ($stmt->execute()) {
            echo "Inscription réussie ! Vous pouvez maintenant vous connecter.";
        } else {
            echo "Une erreur s'est produite lors de l'inscription. Veuillez réessayer.";
        }
    } catch (PDOException $e) {
        die("Erreur lors de l'inscription : " . $e->getMessage());
    }
} else {
    echo "Requête invalide. Veuillez soumettre le formulaire.";
}
?>
