<?php
// Inclure le fichier de connexion à la base de données
require_once 'db.php';

// Vérifier que les données POST sont reçues
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupérer les données soumises via POST
    $email = trim($_POST['email']); // Supprimer les espaces inutiles
    $password = $_POST['password'];

    // Vérifier que l'e-mail est valide
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("Adresse e-mail invalide.");
    }

    // Rechercher l'utilisateur par email
    try {
        $stmt = $pdo->prepare("SELECT password FROM users WHERE email = :email");
        $stmt->bindParam(':email', $email);
        $stmt->execute();

        // Récupérer l'utilisateur
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // Vérifier si l'utilisateur existe et si le mot de passe est correct
        if ($user && password_verify($password, $user['password'])) {
            // Connexion réussie, rediriger vers la nouvelle page
            header("Location: formulaire.html");
            exit(); // Arrête l'exécution du script après la redirection
        } else {
            echo "Email ou mot de passe incorrect.";
        }
    } catch (PDOException $e) {
        die("Erreur lors de la connexion : " . $e->getMessage());
    }
} else {
    echo "Requête invalide. Veuillez soumettre le formulaire.";
}
?>
