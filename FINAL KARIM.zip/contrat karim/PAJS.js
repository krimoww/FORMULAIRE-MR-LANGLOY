// Effet d'animation sur le bouton "Créer un Formulaire"
const startButton = document.getElementById('startButton');
if (startButton) {
    startButton.addEventListener('mouseover', () => {
        startButton.style.transform = 'scale(1.1)';
        startButton.style.transition = 'transform 0.2s ease-in-out';
    });

    startButton.addEventListener('mouseout', () => {
        startButton.style.transform = 'scale(1)';
    });
}

// Défilement fluide pour les liens de navigation internes (#contact, #help)
const navLinks = document.querySelectorAll('.nav-buttons a');
navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        const href = link.getAttribute('href');
        if (href.startsWith('#')) { // Ne bloque que les liens internes
            e.preventDefault();
            const targetId = href.substring(1);
            const targetElement = document.getElementById(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start',
                });
            }
        }
    });
});
// Sélecteur pour basculer entre les modes
const toggleDarkModeButton = document.createElement('button');
toggleDarkModeButton.className = 'toggle-dark-mode';
toggleDarkModeButton.innerText = 'Mode Sombre';

// Ajout du bouton au body
document.body.appendChild(toggleDarkModeButton);

// Gestionnaire d'événements pour activer/désactiver le mode sombre
toggleDarkModeButton.addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');

    // Mise à jour du texte du bouton
    toggleDarkModeButton.innerText = 
        document.body.classList.contains('dark-mode') ? 'Mode Clair' : 'Mode Sombre';
});
